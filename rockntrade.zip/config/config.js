document.title = 'RocknTrade Website';

document.getElementById('website-name').textContent = '“ Rock and Trade ”';

document.getElementById('footer-copyright-name').textContent = 'RocknTrade';
