document.title = 'RocknTrade Website';

document.getElementById('website-name').textContent = '“ Rock and Trade ”';

document.getElementById('footer-copyright-name').textContent = 'RocknTrade';

document.getElementById('company-phone').textContent = '+852-8191-5714';

document.getElementById('company-address').textContent =
  '香港上環禧利街27號富輝商業中心702室';

document.getElementById('company-map').src =
  'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d1845.9052051884005!2d114.15015645816077!3d22.28517047820338!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3404007c14e48209%3A0x84b17dd87c53ba5e!2z6aaZ5riv5LiK55Kw56an5Yip6KGXMjfomZ_lr4zovonllYbkuJrkuK3lv4M!5e0!3m2!1szh-CN!2stw!4v1646098417303!5m2!1szh-TW!2stw';
