document.title = 'RocknTrade Website';

document.getElementById('website-name').textContent = '“ Rock and Trade ”';
