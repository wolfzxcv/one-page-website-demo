document.title = 'Posen Technology';

document.getElementById('website-name').textContent = '“ Posen Technology ”';
