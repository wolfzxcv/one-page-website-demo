document.title = 'Posen Technology';

document.getElementById('website-name').textContent = '“ Posen Technology ”';

document.getElementById('footer-copyright-name').textContent =
  'Posen Technology';

document.getElementById('company-phone').textContent = '+886-4-2322-3088';

document.getElementById('company-address').textContent =
  '台北市大安區忠孝東路三段136號7樓之3';

document.getElementById('company-map').src =
  'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3614.7807818128317!2d121.5354389153611!3d25.04151254414346!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3442abd7db131515%3A0xd24f200c16186b9!2zMTA25Y-w5YyX5biC5aSn5a6J5Yy65b-g5a2d5Lic6Lev5LiJ5q61MTM2LTEx6Jmf!5e0!3m2!1szh-CN!2stw!4v1646098087310!5m2!1szh-TW!2stw';
