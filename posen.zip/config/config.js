document.title = 'Posen Technology';

document.getElementById('website-name').textContent = '“ Posen Technology ”';

document.getElementById('company-service').innerHTML =
  '<div class="col-sm-6 col-lg-4"><div class="media" data-aos="fade-up" data-aos-delay="200"    data-aos-duration="400"><img class="mr-4" src="images/service3.png" alt="DB" /><div class="media-body">      <h5>資料庫及應用整合</h5><span style="color: black">企業商業需求日新月異，各種服務所要求的反應時間也越來越即時，為了因應業務上面的需求，IT 資訊架構上無論服務或是維運上也必須更為妥善及完整，身為企業資訊系統核心的資料庫架構，更是需要可以提供 7X24 小時不中斷且具備高安全性、高可用性、高效能、低風險性、低維護難度的“三高二低”的服務標準。</span></div></div></div><div class="col-sm-6 col-lg-4"><div class="media" data-aos="fade-up" data-aos-delay="400"    data-aos-duration="600"><img class="mr-4" src="images/service4.png" alt="ERP" /><div class="media-body"><h5>ERP 系統</h5><span style="color: black">由不同的應用程式和工具組成,將企業的所有層面都整合到一個綜合資訊系統中心。其部門功能包括財務與會計,人力資源,客戶關係管理,生產管理,庫存管理,電子商貿。</span></div></div></div><div class="col-sm-6 col-lg-4"><div class="media" data-aos="fade-up" data-aos-delay="600"    data-aos-duration="800"><img class="mr-4" src="images/service5.png" alt="VDI" /><div class="media-body"><h5>虛擬桌面基礎架 (VDI)</h5><span style="color: black">VDI 讓IT可集中管理,進而簡化管理、降低成本，維持合規性。透過條件式存取決策。強大的原則控制可確保資料安全性與端點合規性依據驗證強度、網絡、位置和裝置合規性等多種條件來施行存取方式，保護裝置、免遭盜用。</span></div></div></div><div class="col-sm-6 col-lg-4"><div class="media"  data-aos="fade-up" data-aos-delay="800" data-aos-duration="1000"><img class="mr-4" src="images/service1.png" alt="SaaS" /><div class="media-body"><h5>雲端軟體服務 (SaaS)</h5><span style="color: black">雲端服務，特別是 SaaS 的基本優勢是使用者可以使用任何裝置（個人電腦、平板電腦、智慧型手機）並隨時隨地使用軟體服務。此外，即使使用者使用不同的裝置，資料也會同步。使用者在個人電腦、平板電腦、智慧型手機中看到的資料都會是一樣的。網路速度在這些年來變快了，因此可以也透過行動網路來使用 SaaS，而不會覺得連線緩慢。隨著雲端服務的發展，透過在雲端（網際網路）上操作資料和應用程式，人們使用所有的軟體服務不再受限於地點和時間。</span></div></div></div><div class="col-sm-6 col-lg-4"><div    class="media" data-aos="fade-up" data-aos-delay="1000" data-aos-duration="1200"><img class="mr-4" src="images/service2.png" alt="Consultant" /><div class="media-body"><h5>顧問服務</h5><span style="color: black">普森能有效為客戶提供客製化的資訊科技方案助你輕鬆設計表單、建構流程、整合企業異質系統。憑藉我們過去的經驗，我們有信心能夠幫助你改善生產力、降低營運成本，助你的業務發展得更成功！</span></div></div></div>';

document.getElementById('footer-copyright-name').textContent =
  'Posen Technology';

document.getElementById('company-phone').textContent = '+886-4-2322-3088';

document.getElementById('company-address').textContent =
  '台北市大安區忠孝東路三段136號7樓之3';

document.getElementById('company-map').src =
  'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3614.7807818128317!2d121.5354389153611!3d25.04151254414346!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3442abd7db131515%3A0xd24f200c16186b9!2zMTA25Y-w5YyX5biC5aSn5a6J5Yy65b-g5a2d5Lic6Lev5LiJ5q61MTM2LTEx6Jmf!5e0!3m2!1szh-CN!2stw!4v1646098087310!5m2!1szh-TW!2stw';
