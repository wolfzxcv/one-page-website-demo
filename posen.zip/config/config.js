document.title = 'Posen Technology';

document.getElementById('website-name').textContent = '“ Posen Technology ”';

document.getElementById('footer-copyright-name').textContent =
  'Posen Technology';
